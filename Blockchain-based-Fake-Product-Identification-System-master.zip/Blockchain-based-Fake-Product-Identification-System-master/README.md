# Blockchain based Fake Product Identification System

This is a project which aims at creation of an identification system which can distinguish between real products and their fake counterparts.<br>
Each product would have a barcode embedded with it which is tied to the blockchain system. Scanning the barcode would be able to determine the authenticity of the product.
